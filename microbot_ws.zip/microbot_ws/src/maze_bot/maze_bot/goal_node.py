import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist, Point
import sys
import math

class Robot_goal(Node):

    def __init__(self):
        super().__init__('goal_move_node')
        self.velocity_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.pose_sub = self.create_subscription(Odometry,'/odom', self.pose_callback,10)
        timer_period = 0.2  # seconds
        self.timer = self.create_timer(timer_period, self.go_to_goal_function)
        self.robot_pose = Point()
        self.goal_pose = Point()
        self.vel_msg =Twist()
        self.angle_to_goal = 0; self.distance_to_goal = 0

    def pose_callback(self,data):
        self.robot_pose_x = data.pose.pose.position.x
        self.robot_pose_y = data.pose.pose.position.y
        quaternion = data.pose.pose.orientation
        (roll, pitch, yaw) = self.euler_from_quaternion(quaternion.x,quaternion.y,quaternion.z,quaternion.w,)
        self.robot_pose.z = yaw


    def go_to_goal_function(self):
        self.goal_pose.x = float(sys.argv[1])
        self.goal_pose.y = float(sys.argv[2])
        self.angle_offset = float(sys.argv[3])  

        self.distance_to_goal = math.sqrt(pow((self.goal_pose.x - self.robot_pose.x),2) + pow((self.goal_pose.y - self.robot_pose.y),2) ) 
        self.angle_to_goal = math.atan((self.goal_pose.y - self.robot_pose.y) / (self.goal_pose.x - self.robot_pose.x)) + self.angle_offset

        # Angle error that we have to recude to get to the desired position
        self.angle_to_turn = self.angle_to_goal - self.robot_pose.z

        if self.angle_to_turn > 0.1 :
            #Pause and rotates according the angle error, but it stays in its place
            self.vel_msg.angular.z = self.angle_to_turn
            self.vel_msg.linear.x = 0.0
        else:
            #know that the angle error has been reduced, then it moves
            self.vel_msg.linear.x = self.distance_to_goal

        #print messge in console
        msg = 'DTG: {:3f} ATG: {:3f}'.format(self.distance_to_goal, self.angle_to_turn )
        self.get_logger().info(msg)
        self.velocity_pub.publish(self.vel_msg)

    def euler_from_quaternion(self, x, y, z, w):
        t0 = +2.0 * (w * x + y * z)
        t1 = +1.0 - 2.0 * (x * x + y *y)
        roll_x = math.atan2(t0, t1) 

        t2 = +2.0 * (w * y - z * x)
        t2 = +1.0 if t2 > +1.0 else t2
        t2 = -1.0 if t2 < -1.0 else t2
        pitch_y = math.asin(t2)

        t3 = +2.0 * (w * z + x * y)
        t4 = +1.0 - 2.0 * (y * y + z * z)
        yaw_z = math.atan2(t3, t4)

        return roll_x, pitch_y, yaw_z

def main(args=None):
    rclpy.init(args=args)

    minimal_publisher = Robot_goal()

    rclpy.spin(minimal_publisher)
    minimal_publisher.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()