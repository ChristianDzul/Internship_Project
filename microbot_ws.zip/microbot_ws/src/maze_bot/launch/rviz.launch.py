##Basic strcuture to creater a launch file
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    get_package_share_dir = get_package_share_directory("maze_bot")
    urdf = os.path.join(get_package_share_dir,"urdf","micromouse.urdf") ##vairable to acces the urdf file
    
    return LaunchDescription([
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            arguments=[urdf] ##calling variable with the path
        ),

        Node(
            package='joint_state_publisher_gui',
            executable='joint_state_publisher_gui',
            name='joint_state_publisher_gui',
            arguments=[urdf] ##calling variable with the path
        ),

        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            output='screen',
            ##arguments=['-d', '/path/to/your/urdf_display_config.rviz']
        ),



        # Node(
        #     package='maze_bot',
        #     executable='talker_node',
        #     name='Publisher',
        #     output='screen',
        #     ##arguments=['-d', '/path/to/your/urdf_display_config.rviz']
        # ),

        # Node(
        #     package='maze_bot',
        #     executable='listener_node',
        #     name='Listener',
        #     output='screen',
        #     ##arguments=['-d', '/path/to/your/urdf_display_config.rviz']
        # ),
    ])
