import os
import subprocess
from ament_index_python.packages import get_package_share_directory, get_package_prefix

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, SetEnvironmentVariable
from launch.substitutions import LaunchConfiguration
from launch.launch_description_sources import PythonLaunchDescriptionSource

from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue

def generate_launch_description():
    micromouse_description_dir = get_package_share_directory('maze_bot')
    micromouse_description_share = os.path.join(get_package_prefix('maze_bot'), 'share')
    gazebo_ros_dir = get_package_share_directory('gazebo_ros')
    world_path = os.path.join(get_package_share_directory('maze_bot'), 'Mazes', 'Maze_01.world')

    model_arg = DeclareLaunchArgument(
        name='model', 
        default_value=os.path.join(micromouse_description_dir, 'urdf', 'micromouse.urdf'),
        description='Absolute path to robot urdf file'
    )

    env_var = SetEnvironmentVariable('GAZEBO_MODEL_PATH', micromouse_description_share)

    # Execute xacro command to process URDF
    urdf_path = os.path.join(micromouse_description_dir, 'urdf', 'micromouse.urdf')
    xacro_output = subprocess.run(['xacro', urdf_path], capture_output=True, text=True)
    urdf = xacro_output.stdout

    robot_description = {'robot_description': urdf}

    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[robot_description]
    )

    start_gazebo_server = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(gazebo_ros_dir, 'launch', 'gzserver.launch.py'),
        ),
        launch_arguments={'world': world_path}.items()
    )

    start_gazebo_client = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(gazebo_ros_dir, 'launch', 'gzclient.launch.py')
        )
    )

    spawn_robot = Node(
        package='gazebo_ros', 
        executable='spawn_entity.py',
        arguments=['-entity', 'micromouse', '-topic', 'robot_description'],
        output='screen'
    )

    return LaunchDescription([
        env_var,
        model_arg,
        start_gazebo_server,
        start_gazebo_client,
        robot_state_publisher_node,
        spawn_robot
    ])
